# KneeGears
Hackathon at Srinivas University
Personal Assistant for Students
